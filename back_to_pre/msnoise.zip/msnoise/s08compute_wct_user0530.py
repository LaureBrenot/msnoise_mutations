"""
Wavelet Coherence Transform (WCT) Computation
This script performs the computation of the Wavelet Coherence Transform (WCT), a tool used to analyze the correlation between two time series in the time-frequency domain. The script supports parallel processing and interacts with a database to manage job statuses.

Filter Configuration Parameters
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

* |wct_minlag|
* |wct_maxdt|
* |wct_mincoh|
* |wct_codacycles|
* |wct_ns|
* |wct_nt|
* |wct_vpo|
* |wct_nptsfreq|
* |wct_min_nonzero|
* |wct_norm|
* |hpc|

This process is job-based, so it is possible to run several instances in
parallel.


To run this step:

.. code-block:: sh

    $ msnoise cc dvv compute_wct

This step also supports parallel processing/threading:

.. code-block:: sh

    $ msnoise -t 4 cc dvv compute_wct

will start 4 instances of the code (after 1 second delay to avoid database
conflicts). This works both with SQLite and MySQL but be aware problems
could occur with SQLite.

"""

import os
import time
import numpy as np
import pandas as pd
import xarray as xr
import scipy.signal
import pycwt as wavelet
from scipy.signal import convolve2d
from obspy.signal.regression import linear_regression
from .api import *
import logbook
import scipy
import scipy.optimize
import scipy.fft as sf 


# ============================================================================
# ADAPTIVE CODA WINDOW DETECTION (integrated with MSNoise API)
# ============================================================================

class CodaDetector:
    """Simple coda window detector with minimum time constraint"""
    
    def __init__(self, dt=0.05, velocity=2.0, safety_factor=1.3, min_coda_time=8.0):
        self.dt = dt
        self.velocity = velocity
        self.safety_factor = safety_factor
        self.min_coda_time = min_coda_time
        
    def detect_coda_window(self, t, ccf, distance_km):
        """Detect coda window using percentage method with minimum time"""
        
        if distance_km is None:
            distance_km = self._estimate_distance(t, ccf)
            if distance_km is None:
                return self.min_coda_time, -self.min_coda_time, {}
        
        if distance_km is not None and distance_km == 0.0:
            logger.debug("Autocorrelation detected, using minimum coda time")
            diagnostics = {
                'distance_km': 0.0,
                'surface_wave_time': 0.0,
                'calculated_time': self.min_coda_time,
                'coda_start': self.min_coda_time,
                'constraint': 'autocorrelation'
            }
            return self.min_coda_time, -self.min_coda_time, diagnostics
    
        # Core calculation
        surface_wave_time = distance_km / self.velocity
        calculated_time = surface_wave_time * self.safety_factor
        coda_start = max(calculated_time, self.min_coda_time)
        
        # Simple diagnostics
        diagnostics = {
            'distance_km': distance_km,
            'surface_wave_time': surface_wave_time,
            'calculated_time': calculated_time,
            'coda_start': coda_start,
            'constraint': 'minimum' if coda_start == self.min_coda_time else 'physics'
        }
        
        return coda_start, -coda_start, diagnostics
    
    def _estimate_distance(self, t, ccf):
        """Estimate distance from first arrival"""
        try:
            from scipy import signal
            envelope = np.abs(signal.hilbert(ccf))
            center_idx = len(t) // 2
            pos_envelope = envelope[center_idx:]
            pos_time = t[center_idx:]
            
            threshold = 0.5 * np.max(pos_envelope)
            peaks, _ = signal.find_peaks(pos_envelope, height=threshold, distance=int(5/self.dt))
            
            if len(peaks) > 0:
                first_peak_time = pos_time[peaks[0]]
                estimated_distance = first_peak_time * self.velocity * 1.1
                if 5 <= estimated_distance <= 500:
                    return estimated_distance
            return None
        except:
            return None

def get_all_station_distances(db):
    """
    Pre-calculate distances for all station pairs using MSNoise's get_interstation_distance API.
    
    Parameters:
    -----------
    db : database session
        MSNoise database session
        
    Returns:
    --------
    dict
        Dictionary with station pair keys and distance values in km
    """
    from itertools import combinations
    
    logger.info("Pre-calculating all station distances...")
    
    # Get all stations from database
    stations = get_stations(db, all=True)
    
    # Filter stations that have coordinates
    valid_stations = []
    for station in stations:
        if station.X is not None and station.Y is not None:
            valid_stations.append(station)
        else:
            logger.debug(f"Station {station.net}.{station.sta} has no coordinates, skipping")
    
    logger.info(f"Found {len(valid_stations)} stations with coordinates")
    
    # Calculate distances for all station pairs
    distances = {}
    
    for station1, station2 in combinations(valid_stations, 2):
        try:
            # Calculate distance using MSNoise's built-in function
            distance = get_interstation_distance(station1, station2, coordinates="DEG")
            
            # Create comprehensive key formats for this pair
            # Basic formats
            basic_keys = [
                f"{station1.net}.{station1.sta}:{station2.net}.{station2.sta}",
                f"{station2.net}.{station2.sta}:{station1.net}.{station1.sta}",
                f"{station1.net}.{station1.sta}_{station2.net}.{station2.sta}",
                f"{station2.net}.{station2.sta}_{station1.net}.{station1.sta}",
                # Station codes only
                f"{station1.sta}:{station2.sta}",
                f"{station2.sta}:{station1.sta}",
                f"{station1.sta}_{station2.sta}",
                f"{station2.sta}_{station1.sta}",
            ]
            
            # Add formats with location codes (common in MSNoise jobs)
            location_formats = [
                f"{station1.net}.{station1.sta}.--:{station2.net}.{station2.sta}.--",
                f"{station2.net}.{station2.sta}.--:{station1.net}.{station1.sta}.--",
                f"{station1.net}.{station1.sta}.---{station2.net}.{station2.sta}.--",
                f"{station2.net}.{station2.sta}.---{station1.net}.{station1.sta}.--",
                f"{station1.net}.{station1.sta}.--_{station2.net}.{station2.sta}.--",
                f"{station2.net}.{station2.sta}.--_{station1.net}.{station1.sta}.--",
            ]
            
            # Combine all key formats
            all_keys = basic_keys + location_formats
            
            # Store distance with all possible key formats
            for key in all_keys:
                distances[key] = distance
                
            logger.debug(f"Distance {station1.net}.{station1.sta} - {station2.net}.{station2.sta}: {distance:.2f} km")
            
        except Exception as e:
            logger.error(f"Error calculating distance between {station1.net}.{station1.sta} and {station2.net}.{station2.sta}: {e}")
            continue
    
    logger.info(f"Pre-calculated {len(distances)//(len(basic_keys) + len(location_formats))} unique station pair distances")
    logger.info(f"Total cache entries: {len(distances)}")
    
    # Debug: show a few cache keys
    sample_keys = list(distances.keys())[:10]
    logger.debug(f"Sample cache keys: {sample_keys}")
    
    return distances



def get_distance_from_cache(distances_cache, station1, station2):
    """
    Get distance from pre-calculated cache.
    
    Parameters:
    -----------
    distances_cache : dict
        Pre-calculated distances dictionary
    station1, station2 : str
        Station names (can include location codes like 8K.ASK.-- or just 8K.ASK)
        
    Returns:
    --------
    float or None
        Distance in kilometers, or None if not found or if it's an autocorrelation
    """
    def clean_station_name(station_name):
        """Clean station name by removing location/channel codes"""
        # Remove location codes (anything after the second dot)
        parts = station_name.split('.')
        if len(parts) >= 2:
            # Keep only NET.STA, remove location/channel codes
            return f"{parts[0]}.{parts[1]}"
        return station_name
    
    # Clean the station names
    clean_sta1 = clean_station_name(station1)
    clean_sta2 = clean_station_name(station2)
    
    logger.debug(f"Looking for distance between {station1} ({clean_sta1}) and {station2} ({clean_sta2})")
    
    # Handle autocorrelations (same station)
    if clean_sta1 == clean_sta2:
        logger.debug(f"Autocorrelation detected for {clean_sta1}, distance = 0.0 km")
        return 0.0
    
    # For cross-correlations, try different key formats with both original and cleaned names
    possible_keys = [
        # Try with cleaned names first
        f"{clean_sta1}:{clean_sta2}",
        f"{clean_sta2}:{clean_sta1}",
        f"{clean_sta1}_{clean_sta2}",
        f"{clean_sta2}_{clean_sta1}",
        # Try with original names
        f"{station1}:{station2}",
        f"{station2}:{station1}",
        f"{station1}_{station2}",
        f"{station2}_{station1}",
        # Try extracting just station codes (without network)
        f"{clean_sta1.split('.')[1]}:{clean_sta2.split('.')[1]}" if '.' in clean_sta1 and '.' in clean_sta2 else None,
        f"{clean_sta2.split('.')[1]}:{clean_sta1.split('.')[1]}" if '.' in clean_sta1 and '.' in clean_sta2 else None,
    ]
    
    # Filter out None values
    possible_keys = [k for k in possible_keys if k is not None]
    
    logger.debug(f"Trying keys: {possible_keys[:4]}...")  # Log first few keys
    
    for key in possible_keys:
        if key in distances_cache:
            logger.debug(f"Found cached distance for {station1}-{station2} using key '{key}': {distances_cache[key]:.2f} km")
            return distances_cache[key]
    
    logger.debug(f"No cached distance found for {station1}-{station2} after trying {len(possible_keys)} key formats")
    return None
    
# ============================================================================
# MODIFIED WCT FUNCTIONS WITH MSNoise API INTEGRATION
# ============================================================================

def compute_wct_dvv_adaptive(freqs, tvec, WXamp, Wcoh, delta_t, distance_km=None, 
                           coda_detector=None, ref_waveform=None, 
                           coda_cycles=20, mincoh=0.5, maxdt=0.2, 
                           min_nonzero=0.25, freqmin=0.1, freqmax=2.0):
    """
    Compute the dv/v values with adaptive coda window detection.
    
    Parameters
    ----------
    freqs : numpy.ndarray
        Frequency values corresponding to the wavelet transform.
    tvec : numpy.ndarray
        Time vector.
    WXamp : numpy.ndarray
        Amplitude of the cross-wavelet transform.
    Wcoh : numpy.ndarray
        Wavelet coherence.
    delta_t : numpy.ndarray
        Time delays between signals.
    distance_km : float, optional
        Distance between stations in km. If None, will be estimated.
    coda_detector : CodaDetector, optional
        Coda detector instance. If None, uses default parameters.
    ref_waveform : numpy.ndarray, optional
        Reference waveform for distance estimation if distance_km is None.
    coda_cycles : int, optional
        Number of coda cycles to consider. Default is 20.
    mincoh : float, optional
        Minimum coherence value for weighting. Default is 0.5.
    maxdt : float, optional
        Maximum time delay for weighting. Default is 0.2.
    min_nonzero : float, optional
        Minimum percentage of non-zero weights required for valid estimation. Default is 0.25.
    freqmin : float, optional
        Minimum frequency for calculation. Default is 0.1 Hz.
    freqmax : float, optional
        Maximum frequency for calculation. Default is 2.0 Hz.
    
    Returns
    -------
    tuple
        dvv values (percentage), errors (percentage), weighting function, and coda diagnostics.
    """   
    import warnings
    from scipy.optimize import OptimizeWarning
    
    # Initialize coda detector if not provided
    if coda_detector is None:
        dt = tvec[1] - tvec[0] if len(tvec) > 1 else 0.05
        coda_detector = CodaDetector(dt=dt)
    
    # Determine adaptive lag_min using coda detector
    if distance_km is not None or ref_waveform is not None:
        lag_min, _, coda_diagnostics = coda_detector.detect_coda_window(
            tvec, ref_waveform if ref_waveform is not None else np.zeros_like(tvec), 
            distance_km
        )
        logger.info(f"Adaptive coda window: lag_min = {lag_min:.2f}s, constraint = {coda_diagnostics.get('constraint', 'unknown')}")
    else:
        lag_min = coda_detector.min_coda_time  # Fallback to minimum
        coda_diagnostics = {'constraint': 'fallback', 'coda_start': lag_min}
        logger.warning("No distance or reference waveform provided, using minimum coda time")
    
    inx = np.where((freqs >= freqmin) & (freqs <= freqmax))  # Filter frequencies within the specified range
    dvv, err = np.zeros(len(inx[0])), np.zeros(len(inx[0])) # Initialize dvv and err arrays

    # Weighting function based on WXamp
    weight_func = np.log(np.abs(WXamp)) / np.log(np.abs(WXamp)).max()
    zero_idx = np.where((Wcoh < mincoh) | (delta_t > maxdt))
    wf = (weight_func + abs(np.nanmin(weight_func))) / weight_func.max()
    wf[zero_idx] = 0
    
    # Track frequencies with estimation issues
    problematic_freqs = []

    # Loop through frequency indices for linear regression
    for ii, ifreq in enumerate(inx[0]):
        period = 1.0 / freqs[ifreq]
        lag_max = lag_min + (period * coda_cycles)  # Use adaptive lag_min

        # Coda selection
        tindex = np.where(((tvec >= -lag_max) & (tvec <= -lag_min)) | ((tvec >= lag_min) & (tvec <= lag_max)))[0]

        if len(tvec) > 2:
            if not np.any(delta_t[ifreq]):
                continue

            delta_t[ifreq][tindex] = np.nan_to_num(delta_t[ifreq][tindex])
            w = wf[ifreq] # Weighting function for the specific frequency
            non_zero_mask = w > 0
            nzc_perc = np.count_nonzero(non_zero_mask[tindex]) / len(tindex)
            
            n_nonzero_in_coda = int(np.count_nonzero(w[tindex] > 0))
            if n_nonzero_in_coda == 0:
                dvv[ii], err[ii] = np.nan, np.nan
                logger.warning(
                    f"f={freqs[ifreq]:.3f}Hz: all {len(tindex)} coda weights "
                    f"are zero (Wcoh<{mincoh} or |WXdt| >{maxdt}s everywhere). "
                    f"maxdt may be too small for the actual |dv/v|. "
                    f"dvv set to NaN.")
                continue
            
            if nzc_perc >= min_nonzero:
                
                with warnings.catch_warnings(record=True) as w_catcher:
                    warnings.simplefilter("always", OptimizeWarning)

                    m, em = linear_regression(tvec[tindex], delta_t[ifreq][tindex], w[tindex], intercept_origin=True)
                    
                    if any(issubclass(warning.category, OptimizeWarning) for warning in w_catcher):
                        problematic_freqs.append(freqs[ifreq])
                        
                dvv[ii], err[ii] = -m, em
            else:
                dvv[ii], err[ii] = np.nan, np.nan
        else:
            logger.debug('Not enough points to estimate dv/v for WCT')
            
    if problematic_freqs:
        logger.warning(f"Covariance estimation issues between {min(problematic_freqs):.2f}-{max(problematic_freqs):.2f} Hz: Modify min_nonzero (current: {min_nonzero}), mincoh (current: {mincoh}), maxdt (current: {maxdt}) and/or coda_cycles (current: {coda_cycles})")
    
    return dvv * 100, err * 100, wf, coda_diagnostics

def get_avgcoh_adaptive(freqs, tvec, wcoh, freqmin, freqmax, distance_km=None, 
                       coda_detector=None, ref_waveform=None, coda_cycles=20):
    """
    Calculate the average wavelet coherence with adaptive coda window.
    
    Parameters similar to compute_wct_dvv_adaptive but focused on coherence calculation.
    """
    # Initialize coda detector if not provided
    if coda_detector is None:
        dt = tvec[1] - tvec[0] if len(tvec) > 1 else 0.05
        coda_detector = CodaDetector(dt=dt)
    
    # Determine adaptive lag_min
    if distance_km is not None or ref_waveform is not None:
        lag_min, _, _ = coda_detector.detect_coda_window(
            tvec, ref_waveform if ref_waveform is not None else np.zeros_like(tvec), 
            distance_km
        )
    else:
        lag_min = coda_detector.min_coda_time
    
    inx = np.where((freqs >= freqmin) & (freqs <= freqmax)) 
    coh = np.zeros(inx[0].shape)

    for ii, ifreq in enumerate(inx[0]):     
        period = 1.0/freqs[ifreq]
        lag_max = lag_min + (period * coda_cycles)  # Use adaptive lag_min
        tindex = np.where(((tvec >= -lag_max) & (tvec <= -lag_min)) | ((tvec >= lag_min) & (tvec <= lag_max)))[0]

        if len(tvec) > 2:
            if not np.any(wcoh[ifreq]) or wcoh[ifreq][tindex].size == 0:
                coh[ii] = np.nan
                continue
            c = np.nanmean(np.abs(wcoh[ifreq][tindex]))
            coh[ii] = c
        else:
            logger.debug('Not enough points to compute average coherence')
            coh[ii] = np.nan

    return coh

def process_wct_job_adaptive(pair, day, params, taxis, filters, distances_cache=None):
    station1, station2 = pair.split(":")

    # ------------------------------------------------------------------
    # Distance cache
    # ------------------------------------------------------------------
    distance_km = None
    if distances_cache:
        distance_km = get_distance_from_cache(distances_cache, station1, station2)
        if distance_km is not None:
            logger.debug(f"Cached distance {station1}-{station2}: {distance_km:.2f} km")
        else:
            logger.warning(f"No cached distance for {station1}-{station2}, "
                           f"using minimum coda time")
    else:
        logger.warning("No distances cache provided, using minimum coda time for all pairs")

    # ------------------------------------------------------------------
    # Coda detector
    # ------------------------------------------------------------------
    dt = taxis[1] - taxis[0] if len(taxis) > 1 else 0.05
    coda_detector = CodaDetector(
        dt=dt,
        velocity=getattr(params, 'coda_velocity', 2.0),
        safety_factor=getattr(params, 'coda_safety_factor', 1.2),
        min_coda_time=getattr(params, 'dtt_minlag', 6.0)
    )

    # ------------------------------------------------------------------
    # Components
    # ------------------------------------------------------------------
    if station1 == station2:
        components_to_compute = params.components_to_compute_single_station
    else:
        components_to_compute = params.components_to_compute

    logger.info(f"Processing Pair: {pair}, Day: {day} for "
                f"{len(filters)} filters, {len(components_to_compute)} components "
                f"and {len(params.mov_stack)} moving windows")

    # ------------------------------------------------------------------
    # Parameters
    # ------------------------------------------------------------------
    ns                 = params.wct_ns
    nt                 = params.wct_nt
    vpo                = params.wct_vpo
    nptsfreq           = params.wct_nptsfreq
    coda_cycles        = params.dtt_codacycles
    min_nonzero        = params.dvv_min_nonzero
    wct_norm           = params.wct_norm
    wavelet_type       = params.wavelet_type
    mov_stacks         = params.mov_stack
    goal_sampling_rate = params.cc_sampling_rate
    maxdt              = params.dtt_maxdt
    mincoh             = params.dtt_mincoh
    ref_type           = params.ref_type
    ref_end_param      = params.wct_ref_end    # 'auto' or int (days)
    ref_start_param    = params.wct_ref_start  # 'auto' or int (days)
    start_date         = pd.Timestamp(params.startdate)

    try:
        date = pd.to_datetime(day)
    except Exception:
        logger.error(f"Failed to parse date: {day}")
        return False

    operations_succeeded = 0

    # ==================================================================
    for f in filters:
        filterid = int(f['ref'])
        freqmin  = f['low']
        freqmax  = f['high']

        for component in components_to_compute:

            # ----------------------------------------------------------
            # STATIC: load reference once, reuse across all mov_stacks
            # ----------------------------------------------------------
            if ref_type == 'static':
                try:
                    ref = xr_get_ref(station1, station2, component,
                                     filterid, taxis, ignore_network=True)
                    ref = ref.CCF.values
                    if not len(ref):
                        logger.warning(f"Empty static reference for "
                                       f"{station1}:{station2} {component} f{filterid}")
                        continue
                    static_waveform = ref / ref.max() if wct_norm else ref
                except FileNotFoundError as e:
                    logger.error(f"Static reference file not found: {e}, skipping")
                    continue
                except Exception as e:
                    logger.error(f"Error loading static reference: {e}")
                    continue

            # ----------------------------------------------------------
            # MOV_STACK loop
            # ----------------------------------------------------------
            for mov_stack in mov_stacks:
                try:
                    stack_size = int(''.join(
                        filter(str.isdigit, str(mov_stack[0]).split('d')[0])))
                    step_days  = int(''.join(
                        filter(str.isdigit, str(mov_stack[1]).split('d')[0])))

                    # Load all stacked CCF data once � used for both reference
                    # lookup and current-day extraction
                    all_data = xr_get_ccf(station1, station2, component,
                                          filterid, mov_stack, taxis)

                    # ---- Current day waveform ----
                    day_data = all_data[all_data.index == date.normalize()]
                    if day_data.empty:
                        logger.warning(f"No data for {date} in "
                                       f"{station1}:{station2} {component} "
                                       f"f{filterid} m{mov_stack}")
                        continue

                    waveform     = day_data.iloc[0].values
                    new_waveform = waveform / waveform.max() if wct_norm else waveform

                    # ---- Reference waveform (moving) ----
                    if ref_type == 'moving':

                        # --- resolve ref_end ---
                        if ref_end_param == 'auto':
                            ref_end = date - pd.Timedelta(days=stack_size)
                        else:
                            ref_end = date + pd.Timedelta(days=int(ref_end_param))
                            # warn if ref_end overlaps with current stack
                            current_stack_start = date - pd.Timedelta(days=stack_size - 1)
                            if ref_end >= current_stack_start:
                                logger.warning(
                                    f"ref_end={ref_end_param}d overlaps current stack "
                                    f"(stack_size={stack_size}d, "
                                    f"ref_end={ref_end.date()}, "
                                    f"stack_start={current_stack_start.date()}) | "
                                    f"{pair} {component} f{filterid} m{mov_stack} "
                                    f"@ {date.date()}")

                        # --- resolve ref_start ---
                        if ref_start_param == 'auto':
                            # implicit: every stack is stack_size long, no explicit bound
                            ref_start = None
                        else:
                            ref_start = ref_end + pd.Timedelta(days=int(ref_start_param))

                        # --- search for reference candidates ---
                        if ref_start is None:
                            # 'auto'/'auto': unbounded, exact Doc1 behaviour
                            ref_candidates = all_data[all_data.index <= ref_end]
                            window_desc    = f"(-inf, {ref_end.date()}]"
                        else:
                            # bounded window
                            ref_candidates = all_data[
                                (all_data.index >= ref_start) &
                                (all_data.index <= ref_end)
                            ]
                            window_desc = f"[{ref_start.date()}, {ref_end.date()}]"

                            # fallback: window empty, get most recent before ref_end
                            if ref_candidates.empty:
                                fallback = all_data[all_data.index <= ref_end]
                                if not fallback.empty:
                                    logger.warning(
                                        f"No stack in {window_desc}, falling back to "
                                        f"most recent before {ref_end.date()}: "
                                        f"{fallback.index[-1].date()} | "
                                        f"{pair} {component} f{filterid} m{mov_stack}")
                                    ref_candidates = fallback

                        # --- legitimate skip: nothing exists before ref_end ---
                        if ref_candidates.empty:
                            logger.warning(
                                f"No reference stack available before {ref_end.date()} for "
                                f"{station1}:{station2} {component} f{filterid} "
                                f"m{mov_stack} @ {date.date()}, skipping")
                            continue

                        ref_row = ref_candidates.iloc[[-1]]   # most recent available

                        # --- legitimate skip: reference predates data start ---
                        if ref_row.index[0] < start_date:
                            logger.info(
                                f"Best available reference {ref_row.index[0].date()} is "
                                f"before data start {start_date.date()}, skipping | "
                                f"{pair} {component} f{filterid} m{mov_stack}")
                            continue

                        ref_values   = ref_row.iloc[0].values
                        ori_waveform = ref_values / ref_values.max() if wct_norm else ref_values

                        # --- warn if separation is larger than expected (gap in data) ---
                        separation   = (date - ref_row.index[0]).days
                        expected_sep = stack_size + step_days
                        if separation > expected_sep:
                            logger.warning(
                                f"Reference gap detected: separation={separation}d > "
                                f"expected={expected_sep}d (stack_size={stack_size}d + "
                                f"step={step_days}d) | ref={ref_row.index[0].date()}, "
                                f"current={date.date()}, "
                                f"{pair} {component} f{filterid} m{mov_stack}. "
                                f"Integration step should account for this gap.")

                        logger.debug(
                            f"Dynamic ref: {ref_row.index[0].date()} "
                            f"(window {window_desc}, current end={date.date()}, "
                            f"stack_size={stack_size}d, step={step_days}d, "
                            f"separation={separation}d)")

                    else:
                        # static reference loaded before the mov_stack loop
                        ori_waveform = static_waveform
                        separation   = None

                    # ---- WCT computation ----
                    WXamp, WXspec, WXangle, Wcoh, WXdt, freqs, coi = xwt(
                        ori_waveform, new_waveform, goal_sampling_rate,
                        int(ns), float(nt), int(vpo),
                        freqmin, freqmax, int(nptsfreq), wavelet_type, maxdt
                    )

                    dvv, err, wf, coda_diagnostics = compute_wct_dvv_adaptive(
                        freqs, taxis, WXamp, Wcoh, WXdt,
                        distance_km=distance_km,
                        coda_detector=coda_detector,
                        ref_waveform=ori_waveform,
                        coda_cycles=coda_cycles,
                        mincoh=mincoh, maxdt=maxdt, min_nonzero=min_nonzero,
                        freqmin=freqmin, freqmax=freqmax
                    )

                    coh = get_avgcoh_adaptive(
                        freqs, taxis, Wcoh, freqmin, freqmax,
                        distance_km=distance_km,
                        coda_detector=coda_detector,
                        ref_waveform=ori_waveform,
                        coda_cycles=coda_cycles
                    )

                    inx = np.where((freqs >= freqmin) & (freqs <= freqmax))


                    curr_window_days = stack_size
                    if ref_type == 'static':
                        saved_ref_type      = 'static'
                        ref_window_days = 0
                        ref_lag_days    = 0
                    else:
                        saved_ref_type      = 'moving'
                        if ref_start_param == 'auto':
                            ref_window_days = 0
                        else:
                            ref_window_days = abs(int(ref_start_param))
                        ref_lag_days = separation if separation is not None else 0        

                    save_day_wct_results_adaptive(
                        station1, station2, date, component,
                        filterid, mov_stack, taxis,
                        dvv, err, coh, freqs, inx, coda_diagnostics,
                        curr_window_days, ref_window_days, step_days, ref_lag_days,
                        ref_type=saved_ref_type
                    )

                    operations_succeeded += 1

                except Exception as e:
                    logger.error(f"Error processing {component} f{filterid} "
                                 f"m{mov_stack}: {str(e)}")
                    continue

    if operations_succeeded == 0:
        logger.error(f"Job failed completely: {pair} - {day}.")
        return False

    logger.info(f"Job processing complete: {pair} - {day}. "
                f"{operations_succeeded} operations succeeded.")
    return True

def save_day_wct_results_adaptive(station1, station2, date, component, filterid, mov_stack, 
                                 taxis, dvv, err, coh, freqs, inx, coda_diagnostics, curr_window_days, ref_window_days, step_days, ref_lag_days, ref_type='static'):
    """
    Save the WCT results including coda diagnostics.
    
    Same as original save_day_wct_results but includes coda window information.
    """
    # Format filterid with leading zeros (e.g., 1 -> "01")
    filter_str = f"{int(filterid):02d}"
    
    # Format mov_stack (could be string like '10d_1d' or int)
    if isinstance(mov_stack, (list, tuple)):
        mov_stack_str = '_'.join(str(m) for m in mov_stack)
    else:
        mov_stack_str = str(mov_stack)
    
    # Station pair string
    pair_str = f"{station1}_{station2}"
    
    # Create directory structure
    dir_path = os.path.join('WCT', filter_str, mov_stack_str, component, pair_str)
    os.makedirs(dir_path, exist_ok=True)
    
    # Filename is just the date: YYYY-MM-DD.npz
    date_str = date.strftime('%Y-%m-%d')
    filename = f"{date_str}.npz"
    filepath = os.path.join(dir_path, filename)
    
    # Create DataFrames
    freqs_subset = freqs[inx]
    
    # Save to numpy compressed format including coda diagnostics
    np.savez_compressed(
        filepath,
        date=date,
        freqs=freqs_subset,
        dvv=dvv,
        err=err,
        coh=coh,
        taxis=taxis,
        station1=station1,
        station2=station2,
        component=component,
        filterid=filterid,
        mov_stack=mov_stack,
        # Add coda diagnostics
        coda_distance_km=coda_diagnostics.get('distance_km'),
        coda_surface_wave_time=coda_diagnostics.get('surface_wave_time'),
        coda_start=coda_diagnostics.get('coda_start'),
        coda_constraint=coda_diagnostics.get('constraint'),
        curr_window_days=curr_window_days,
        ref_window_days=ref_window_days,
        step_days=step_days,
        ref_lag_days=ref_lag_days,
        ref_type=ref_type
    )
    
    logger.debug(f"Saved WCT results to {filepath} with coda constraint: {coda_diagnostics.get('constraint')}")
    return filepath

       
            
            
            
            
            
####################################
####################################
def smoothCFS(cfs, scales, dt, ns, nt):
    """
    Smooth the continuous wavelet transform coefficients using a Fourier domain approach.
    Parameters
    ----------
    cfs : numpy.ndarray
        Continuous wavelet transform coefficients.
    scales : numpy.ndarray
        Scales used in the wavelet transform.
    dt : float
        Sampling interval.
    ns : int
        Smoothing parameter for the moving average filter.
    nt : float
        Smoothing parameter for the Gaussian filter.
    Returns
    -------
    numpy.ndarray
        Smoothed continuous wavelet transform coefficients.
    """
    N = cfs.shape[1]
    npad = sf.next_fast_len(N, real=True)
    omega = np.arange(1, np.fix(npad / 2) + 1, 1).tolist()
    omega = np.array(omega) * ((2 * np.pi) / npad)
    omega_save = -omega[int(np.fix((npad - 1) / 2)) - 1:0:-1]
    omega_2 = np.concatenate((0., omega), axis=None)
    omega_2 = np.concatenate((omega_2, omega_save), axis=None)
    omega = np.concatenate((omega_2, -omega[0]), axis=None)
    # Normalize scales by DT because we are not including DT in the angular frequencies here.
    # The smoothing is done by multiplication in the Fourier domain.
    normscales = scales / dt

    for kk in range(0, cfs.shape[0]):
        F = np.exp(-nt * (normscales[kk] ** 2) * omega ** 2)
        smooth = np.fft.ifft(F * np.fft.fft(cfs[kk - 1], npad))
        cfs[kk - 1] = smooth[0:N]
    # Convolve the coefficients with a moving average smoothing filter across scales.
    H = 1 / ns * np.ones((ns, 1))

    cfs = conv2(cfs, H)
    return cfs
    
def conv2(x, y, mode='same'):
    """
    Perform 2D convolution of matrices x and y
    """
    return np.rot90(convolve2d(np.rot90(x, 2), np.rot90(y, 2), mode=mode), 2)

def get_wavelet_type(wavelet_type):
    """
    return a wavelet object based on the specified wavelet type and associated parameter
    """
    # Default parameters for each wavelet type
    default_params = {
        'Morlet': 6,
        'Paul': 4,
        'DOG': 2,
        'MexicanHat': 2  # MexicanHat inherits from DOG with m=2
    }

    wavelet_name = wavelet_type[0]

    # If a second argument is provided, use it; otherwise, use the default value
    if len(wavelet_type) == 2:
        param = float(wavelet_type[1])
    else:
        param = default_params[wavelet_name]

    # Get the corresponding wavelet object
    if wavelet_name == 'Morlet':
        return wavelet.Morlet(param)
    elif wavelet_name == 'Paul':
        return wavelet.Paul(param)
    elif wavelet_name == 'DOG':
        return wavelet.DOG(param)
    elif wavelet_name == 'MexicanHat':
        return wavelet.MexicanHat()  # Uses m=2, so no need for param
    else:
        raise logger.error(f"Unknown wavelet type: {wavelet_name}")

def xwt(trace_ref, trace_current, fs, ns=3, nt=0.25, vpo=12, freqmin=0.1, freqmax=8.0, nptsfreq=100, wavelet_type=('Morlet',6.), maxdt=0.1):
    """
    Wavelet coherence transform (WCT) on two time series..
    The WCT finds regions in time frequency space where the two time
    series co-vary, but do not necessarily have high power.
    
    Modified from https://github.com/Qhig/cross-wavelet-transform
    Parameters
    ----------
    trace_ref, trace_current : numpy.ndarray, list
        Input signals.
    fs : float
        Sampling frequency.
    ns : smoothing parameter. 
        Default value is 3
    nt : smoothing parameter. 
        Default value is 0.25
    vpo : float,
        Spacing parameter between discrete scales. Default value is 12.
        Higher values will result in better scale resolution, but
        slower calculation and plot.
        
    freqmin : float,
        Smallest frequency
        Default value is 0.1 Hz
    freqmax : float,
        Highest frequency
        Default value is 8.0 Hz
    nptsfreq : int,
        Number of frequency points between freqmin and freqmax.
        Default value is 100 points
    wavelet_type: list,
        Wavelet type and associated parameter.
        Default Morlet wavelet with a central frequency w0 = 6
    maxdt:float,
        Maximum allowed time delay in seconds. Time delays with absolute values
        exceeding this threshold will be clipped. 
        Default value is 0.1 second.
    
    Returns
        ----------
    WXamp : numpy.ndarray
        Amplitude of the cross-wavelet transform.
    WXspec : numpy.ndarray
        Complex cross-wavelet transform, representing both magnitude and phase information.
    WXangle : numpy.ndarray
        Phase angles of the cross-wavelet transform, indicating the phase relationship between the input signals.
    Wcoh : numpy.ndarray
        Wavelet coherence, representing the degree of correlation between the two signals in time-frequency space.
    WXdt : numpy.ndarray
        Time delay between the signals, estimated from the phase angles.
    freqs : numpy.ndarray
        Frequencies corresponding to the scales of the wavelet transform.
    coi : numpy.ndarray
        Cone of influence, representing the region of the wavelet spectrum where edge effects become significant.
    
    """
    mother = get_wavelet_type(wavelet_type) # mother wavelet class: Morlet, Paul, DOG, MexicanHat param 
    # nx represent the number of element in the trace_current array
    nx = np.size(trace_current)
    x_reference = np.transpose(trace_ref)
    x_current = np.transpose(trace_current)
    # Sampling interval
    dt = 1 / fs
    # Spacing between discrete scales, the default value is 1/12
    dj = 1 / vpo 
    # Number of scales less one, -1 refers to the default value which is J = (log2(N * dt / so)) / dj.
    J = -1
    # Smallest scale of the wavelet, default value is 2*dt
    s0 = 2 * dt  # Smallest scale of the wavelet, default value is 2*dt

    # Creation of the frequency vector
    freqlim = np.linspace(freqmax, freqmin, num=nptsfreq, endpoint=True, retstep=False, dtype=None, axis=0)

    try:
        # Wavelet transforms     # fft : Normalized fast Fourier transform of the input trace, fftfreqs : Fourier frequencies for the calculated FFT spectrum.
        cwt_reference, scales, freqs, coi, fft, fftfreqs = wavelet.cwt(x_reference, dt, dj, s0, J, mother, freqs=freqlim)
        cwt_current, _, _, _, _, _ = wavelet.cwt(x_current, dt, dj, s0, J, mother, freqs=freqlim)
    except Exception as e:
        logger.error(f"Error in wavelet transform: {str(e)}")
        raise

    scales = np.array([[kk] for kk in scales])
    invscales = np.kron(np.ones((1, nx)), 1 / scales)

    # Apply smoothing
    # Before the smoothCFS calls, ensure complex data types:
    power_ref = (invscales * abs(cwt_reference) ** 2).astype(complex)
    power_cur = (invscales * abs(cwt_current) ** 2).astype(complex)
    
    crossCFS = cwt_reference * np.conj(cwt_current)
    WXamp = abs(crossCFS)
    cross_spectrum = (invscales * crossCFS).astype(complex)
    
    # Then call smoothCFS with complex arrays:
    cfs1 = smoothCFS(power_ref, scales, dt, ns, nt)
    cfs2 = smoothCFS(power_cur, scales, dt, ns, nt)
    crossCFS = smoothCFS(cross_spectrum, scales, dt, ns, nt)
    
    # Handle zeros to prevent divide-by-zero
    mask1 = cfs1 > 0
    mask2 = cfs2 > 0
    valid_mask = mask1 & mask2  # Areas where both have power
            
    # Initialize with NaNs
    WXspec = np.full_like(crossCFS, np.nan, dtype=complex)
    Wcoh = np.full_like(crossCFS, np.nan)
    
    # Division operations
    WXspec[valid_mask] = crossCFS[valid_mask] / (np.sqrt(cfs1[valid_mask]) * np.sqrt(cfs2[valid_mask]))
    Wcoh[valid_mask] = abs(crossCFS[valid_mask]) ** 2 / (cfs1[valid_mask] * cfs2[valid_mask])
    WXangle = np.angle(WXspec)

    
    # Clip coherence values to [0,1]
    Wcoh = np.clip(Wcoh, 0.0, 1.0)

    # Calculate time delay
    pp = 2 * np.pi * freqs
    pp2 = np.array([[kk] for kk in pp])
    WXdt = WXangle / np.kron(np.ones((1, nx)), pp2)
    
    #if maxdt is not None:
    #WXdt = np.clip(WXdt, -maxdt, maxdt) 
    
    return WXamp, WXspec, WXangle, Wcoh, WXdt, freqs, coi

def claim_available_jobs(db, batch_size=5, max_attempts=3):
    """
    Claims a batch of available jobs
    
    Parameters:
    ----------
    db : Session
        Database session
    batch_size : int
        Maximum number of jobs to claim at once
    max_attempts : int
        Number of retries if no jobs found
        
    Returns:
    -------
    list
        List of claimed Job objects
    """
    from sqlalchemy import text
    import time
        
    for attempt in range(max_attempts):
        try:
            # Make sure we're not in a transaction already
            if db.in_transaction():
                db.rollback()
            
            # Find available jobs
            available_jobs = db.query(Job).filter(
                Job.flag == 'T',
                Job.jobtype == 'WCT',
                Job.day != 'REF'
            ).limit(batch_size).all()
            
            if not available_jobs:
                if attempt < max_attempts - 1:
                    time.sleep(1 * (attempt + 1))
                    continue
                else:
                    logger.info("No jobs available after {max_attempts} retries")
                    return []
            
            # Make a copy of the job data before updating
            jobs = []
            job_ids = []
            
            for job in available_jobs:
                # Properly create job copies with all required attributes
                job_copy = Job(
                    day=job.day,
                    pair=job.pair,
                    jobtype=job.jobtype,
                    flag='I'
                )
                job_copy.ref = job.ref
                jobs.append(job_copy)
                job_ids.append(job.ref)
            
            # Start a transaction for the update
            if db.in_transaction():
                db.rollback()
            db.begin()
            
            # Update the jobs to mark them as in progress
            update_query = text("""
                UPDATE jobs
                SET flag = 'I', lastmod = NOW()
                WHERE ref IN :job_ids
                AND flag = 'T'  -- Double-check it hasn't been claimed
            """)
            
            result = db.execute(update_query, {'job_ids': tuple(job_ids)})
            updated_count = result.rowcount
            
            # Commit the transaction
            db.commit()
            
            # Check if we actually updated anything (race condition check)
            if updated_count > 0:
                # Only return jobs that were actually updated
                return jobs[:updated_count]
            else:
                if attempt < max_attempts - 1:
                    time.sleep(1 * (attempt + 1))
                    continue
                else:
                    return []
                
        except Exception as e:
            if db.in_transaction():
                db.rollback()
            logger.error(f"Error claiming jobs: {str(e)}")
            time.sleep(1)
    
    return []
  
def main(loglevel="INFO", batch_size=5):
    """
    Main function to process WCT jobs using day job distribution approach
    """
    global logger
    logger = get_logger('msnoise.compute_wct_child', loglevel, with_pid=True)
    logger.info('*** Starting: Compute WCT ***')
    
    # Add small random delay to prevent all processes starting at exactly the same time
    time.sleep(np.random.random() * 2)
    
    try:
        # Initial database connection to get configuration
        db = connect()
        
        # Ensure no lingering transactions
        if hasattr(db, 'in_transaction') and db.in_transaction():
            db.rollback()
            
        params = get_params(db)
        taxis = get_t_axis(db)
        filters = get_filters(db, all=False)
        
        # Convert filters to dictionaries before closing the session
        filter_dicts = []
        for f in filters:
            filter_dicts.append({
                'ref': f.ref,
                'low': f.low,
                'high': f.high,
                'mwcs_low': getattr(f, 'mwcs_low', None),
                'mwcs_high': getattr(f, 'mwcs_high', None),
                'rms_threshold': getattr(f, 'rms_threshold', None),
                'mwcs_wlen': getattr(f, 'mwcs_wlen', None),
                'mwcs_step': getattr(f, 'mwcs_step', None)
            })
            
        params.coda_velocity = float(get_config(db, "dtt_v")) #2.0
        params.coda_safety_factor = float(get_config(db, "coda_safety_factor")) #1.2
        params.dtt_minlag = float(get_config(db, "dtt_minlag"))# 6.0 
        params.ref_type = get_config(db, "ref_type") #'moving'
        params.wct_ref_end   = get_config(db, "ref_end") #'auto'   # reference window ends 10 days before current date
        params.wct_ref_start = get_config(db, "ref_begin") #'auto'   # reference window starts 40 days before current date
        
        # Pre-calculate all station distances 
        try:
            distances_cache = get_all_station_distances(db)
            logger.info(f"Successfully cached distances for station pairs")
        except Exception as e:
            logger.error(f"Error pre-calculating distances: {e}")
            distances_cache = {}
            
        db.close()
        
        # Process jobs in batches to avoid too many database connections
        jobs_processed = 0
        max_jobs_per_process = 1000  # Safety limit
        consecutive_empty_batches = 0
        max_consecutive_empty = 3  # Exit after this many empty batches
        
        while jobs_processed < max_jobs_per_process:
            # Connect to the database and get a batch of jobs
            db = connect()
            
            # Ensure no lingering transactions
            if hasattr(db, 'in_transaction') and db.in_transaction():
                db.rollback()
            
            # Check if there are any jobs left
            job_exists = is_dtt_next_job(db, flag='T', jobtype='WCT')
            if not job_exists:
                logger.info("No more WCT jobs to process")
                db.close()
                break
                
            # Try to claim a batch of jobs
            jobs = claim_available_jobs(db, batch_size)
            
            if not jobs:
                consecutive_empty_batches += 1
                if consecutive_empty_batches >= max_consecutive_empty:
                    logger.info(f"Exiting after {consecutive_empty_batches} empty batches")
                    break
                time.sleep(2)  # Wait before next attempt
                continue
            else:
                consecutive_empty_batches = 0  # Reset counter when we get jobs
                
            # Process each job in the batch
            for job in jobs:
                pair = job.pair
                day = job.day

                # Process this job
                success = process_wct_job_adaptive(pair, day, params, taxis, filter_dicts, distances_cache)
                                
                # Update job status
                db = connect()
                if success:
                    update_job(db, day, pair, 'WCT', 'D')
                else:
                    update_job(db, day, pair, 'WCT', 'E')  # Mark as error
                db.close()
                
                jobs_processed += 1 
                
            # Small delay between batches
            time.sleep(0.5)
            
        logger.info(f"Process completed {jobs_processed} jobs")
                        
    except Exception as e:
        logger.error(f"Error in main processing: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
    finally:
        # Final cleanup
        try:
            if 'db' in locals() and db is not None:
                # Ensure we don't leave transactions open
                if hasattr(db, 'in_transaction') and db.in_transaction():
                    db.rollback()
                db.close()
        except:
            pass

    logger.info(f'*** Finished: Compute WCT ***')